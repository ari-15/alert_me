package com.example.homepage;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import static com.example.homepage.R.id.buttonGoodbye;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button buttonHello = findViewById(R.id.buttonHello);
        buttonHello.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(String.valueOf(getApplicationContext()));
                Class<ActivityButtonHello> activityButtonHelloClass = ActivityButtonHello.class;
                startActivity(intent);
            }

        });

        Button buttonMedicine = findViewById(R.id.buttonMedicine);
        buttonMedicine.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(String.valueOf(getApplicationContext()));
                Class<ActivityButtonMedicine> activityButtonMedicineClass = ActivityButtonMedicine.class;
                startActivity(intent);
            }

        });

        Button buttonGoodbye = findViewById(R.id.buttonGoodbye);
        buttonGoodbye.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(String.valueOf(getApplicationContext()));
                Class<ActivityButtonGoodbye> activityButtonGoodbyeClass = ActivityButtonGoodbye.class;
                startActivity(intent);
            }
        });
    }
}